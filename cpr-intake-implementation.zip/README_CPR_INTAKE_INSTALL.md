# CPR Intake Install Instructions

## Files to add

Copy these files into the existing `TheArchitect1111/cpr-site` repo:

```text
app/intake/page.tsx
app/api/intake/route.ts
docs/cpr-intake-airtable-schema.md
docs/cpr-intake-env-vars.md
docs/cpr-intake-profile-mapping.md
```

## URL after deploy

```text
https://cpr-site.vercel.app/intake
```

## Local test

```bash
npm install
npm run dev
```

Then open:

```text
http://localhost:3000/intake
```

## Production test

After files are pushed to GitHub, Vercel should redeploy automatically.

## Important

This implementation creates a working intake page and JSON submission route.

It does not yet upload image/document file binaries to permanent storage. It captures file names and image placement. To store actual files, connect one of these:

- Vercel Blob
- UploadThing
- Cloudinary
- S3
- Airtable attachment fields

Recommended next enhancement: Vercel Blob for documents and Cloudinary for athlete images.
