# CPR Intake Environment Variables

Add these in Vercel Project Settings > Environment Variables.

```env
NEXT_PUBLIC_SITE_URL=https://cpr-site.vercel.app

AIRTABLE_BASE_ID=appxxxxxxxxxxxxxx
AIRTABLE_CPR_INTAKE_TABLE=Athlete Intake
AIRTABLE_API_KEY=patxxxxxxxxxxxxxx

RESEND_API_KEY=re_xxxxxxxxxxxxxx
CPR_FROM_EMAIL=Canadian Prospects Recruitment <onboarding@yourdomain.com>
CPR_STAFF_EMAIL=mmagicman3223@gmail.com
```

## Notes

- Airtable fields must match the schema file.
- Resend requires a verified sender domain before production sending.
- If Airtable variables are not configured, the API route will skip Airtable instead of crashing.
- If Resend variables are not configured, the API route will skip emails instead of crashing.
