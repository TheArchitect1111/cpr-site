# CPR Intake Airtable Schema

Create or update an Airtable table named:

`Athlete Intake`

Recommended fields:

## System
- Profile ID
- Profile Slug
- Profile URL
- Profile Completion
- Status
- Submitted At

## Athlete
- Athlete First Name
- Athlete Last Name
- Preferred Name
- Date of Birth
- Graduation Year
- Gender
- Citizenship
- City
- Province
- Postal Code
- Email
- Mobile Phone
- Referral Source

## Parent / Guardian
- Parent 1 Name
- Parent 1 Relationship
- Parent 1 Email
- Parent 1 Phone
- Parent 2 Name
- Parent 2 Relationship
- Parent 2 Email
- Parent 2 Phone

## Academics
- Current School
- School City
- School Province
- Grade Level
- GPA Unweighted
- GPA Weighted
- Academic Core GPA
- SAT Score
- ACT Score
- NCAA Eligibility Status
- Intended Major
- Academic Honors

## Athletics
- Primary Sport
- Primary Position
- Secondary Position
- Height
- Weight
- Wingspan
- Standing Reach
- Vertical Jump
- Dominant Hand
- Jersey Number
- Class Year
- Athletic Honors

## Team
- Current Team Name
- League
- Head Coach Name
- Coach Email
- Coach Phone
- Team Website
- Trainer Name
- Trainer Email
- Trainer Phone

## Videos & Media Links
- Primary Highlight Video
- Full Game Film 1
- Full Game Film 2
- Full Game Film 3
- Hudl Profile
- YouTube Channel
- Instagram
- X / Twitter
- TikTok
- Other Recruiting Link
- Additional Video Notes

## Documents
- Transcript Upload
- Report Card Upload
- Awards Certificates
- NCAA Eligibility Documents
- Additional Documents

## Bio & Strengths
- Player Bio
- Strength Tags

## Coach Recommendation
- Recommendation Coach Name
- Recommendation Team
- Recommendation Coach Email
- Recommendation Text

## Agreement
- Athlete Signature
- Parent Signature
- Signature Date
- Image Placement JSON

Note: The current implementation stores uploaded file names and image placement names. For real file hosting, add UploadThing, Cloudinary, S3, Airtable attachments, or Vercel Blob.
