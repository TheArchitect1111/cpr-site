# CPR Intake to Athlete Profile Mapping

## Header
- Athlete First Name + Athlete Last Name -> Profile Name
- Primary Position -> Position
- Height -> Height
- Weight -> Weight
- Dominant Hand -> Shoots / Dominant Hand
- Graduation Year -> Class of
- NCAA Eligibility Status -> NCAA Eligibility Badge
- Profile ID -> Header Profile ID

## Contact Row
- Email -> Email
- Mobile Phone -> Phone
- City + Province -> Location
- Parent 1 Name -> Parent Contact

## Academic Card
- Current School -> High School
- Graduation Year -> Grad Year
- GPA Unweighted -> GPA
- GPA Weighted -> GPA Weighted
- Academic Core GPA -> Academic Core GPA
- SAT Score -> SAT
- ACT Score -> ACT
- NCAA Eligibility Status -> NCAA Eligibility

## Athletic Card
- Primary Position -> Position
- Height -> Height
- Weight -> Weight
- Wingspan -> Wingspan
- Vertical Jump -> Vertical Jump
- Standing Reach -> Standing Reach
- Dominant Hand -> Dominant Hand
- Jersey Number -> Jersey Number

## Video Sections
- Primary Highlight Video -> Highlight Video
- Full Game Film 1 -> Mixtapes & Game Film
- Full Game Film 2 -> Mixtapes & Game Film
- Full Game Film 3 -> Mixtapes & Game Film
- Hudl Profile / YouTube Channel -> Social / Media Links

## Image Placement
- profileImage -> Main hero image
- actionPhoto1 -> Player Photos Gallery
- actionPhoto2 -> Player Photos Gallery
- actionPhoto3 -> Player Photos Gallery

## Team Card
- Current Team Name -> Current Team
- League -> League
- Head Coach Name -> Head Coach
- Coach Phone -> Phone
- Coach Email -> Email
- Team Website -> Website
- Trainer Name / Trainer Email / Trainer Phone -> Trainer section

## Bio
- Player Bio -> Player Bio
- Strength Tags -> Strength chips

## Documents
- Transcript Upload -> Documents card
- Report Card Upload -> Documents card
- Awards Certificates -> Documents card
- NCAA Eligibility Documents -> Documents card
- Additional Documents -> Documents card
