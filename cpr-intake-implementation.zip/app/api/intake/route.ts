import { NextResponse } from 'next/server';

type IntakePayload = Record<string, unknown>;

const AIRTABLE_BASE_ID = process.env.AIRTABLE_BASE_ID;
const AIRTABLE_TABLE_NAME = process.env.AIRTABLE_CPR_INTAKE_TABLE || 'Athlete Intake';
const AIRTABLE_API_KEY = process.env.AIRTABLE_API_KEY;

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const CPR_FROM_EMAIL = process.env.CPR_FROM_EMAIL || 'Canadian Prospects Recruitment <onboarding@cpr-site.vercel.app>';
const CPR_STAFF_EMAIL = process.env.CPR_STAFF_EMAIL || 'mmagicman3223@gmail.com';

function text(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}

function list(value: unknown) {
  return Array.isArray(value) ? value.join(', ') : '';
}

function buildProfileSlug(payload: IntakePayload) {
  const first = text(payload.athleteFirstName).toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const last = text(payload.athleteLastName).toLowerCase().replace(/[^a-z0-9]+/g, '-');
  const year = text(payload.graduationYear);
  return [first, last, year].filter(Boolean).join('-') || `athlete-${Date.now()}`;
}

function airtableFields(payload: IntakePayload) {
  const profileSlug = buildProfileSlug(payload);
  const profileUrl = `${process.env.NEXT_PUBLIC_SITE_URL || 'https://cpr-site.vercel.app'}/athletes/${profileSlug}`;

  return {
    'Profile ID': text(payload.profileId),
    'Profile Slug': profileSlug,
    'Profile URL': profileUrl,
    'Profile Completion': Number(payload.profileCompletion || 0),

    'Athlete First Name': text(payload.athleteFirstName),
    'Athlete Last Name': text(payload.athleteLastName),
    'Preferred Name': text(payload.preferredName),
    'Date of Birth': text(payload.dateOfBirth),
    'Graduation Year': text(payload.graduationYear),
    'Gender': text(payload.gender),
    'Citizenship': text(payload.citizenship),
    'City': text(payload.city),
    'Province': text(payload.province),
    'Postal Code': text(payload.postalCode),
    'Email': text(payload.email),
    'Mobile Phone': text(payload.mobilePhone),
    'Referral Source': text(payload.referralSource),

    'Parent 1 Name': text(payload.parentOneName),
    'Parent 1 Relationship': text(payload.parentOneRelationship),
    'Parent 1 Email': text(payload.parentOneEmail),
    'Parent 1 Phone': text(payload.parentOnePhone),
    'Parent 2 Name': text(payload.parentTwoName),
    'Parent 2 Relationship': text(payload.parentTwoRelationship),
    'Parent 2 Email': text(payload.parentTwoEmail),
    'Parent 2 Phone': text(payload.parentTwoPhone),

    'Current School': text(payload.currentSchool),
    'School City': text(payload.schoolCity),
    'School Province': text(payload.schoolProvince),
    'Grade Level': text(payload.gradeLevel),
    'GPA Unweighted': text(payload.gpaUnweighted),
    'GPA Weighted': text(payload.gpaWeighted),
    'Academic Core GPA': text(payload.academicCoreGpa),
    'SAT Score': text(payload.satScore),
    'ACT Score': text(payload.actScore),
    'NCAA Eligibility Status': text(payload.ncaaEligibilityStatus),
    'Intended Major': text(payload.intendedMajor),
    'Academic Honors': text(payload.academicHonors),

    'Primary Sport': text(payload.primarySport),
    'Primary Position': text(payload.primaryPosition),
    'Secondary Position': text(payload.secondaryPosition),
    'Height': text(payload.height),
    'Weight': text(payload.weight),
    'Wingspan': text(payload.wingspan),
    'Standing Reach': text(payload.standingReach),
    'Vertical Jump': text(payload.verticalJump),
    'Dominant Hand': text(payload.dominantHand),
    'Jersey Number': text(payload.jerseyNumber),
    'Class Year': text(payload.classYear),
    'Athletic Honors': text(payload.athleticHonors),

    'Current Team Name': text(payload.currentTeamName),
    'League': text(payload.league),
    'Head Coach Name': text(payload.headCoachName),
    'Coach Email': text(payload.coachEmail),
    'Coach Phone': text(payload.coachPhone),
    'Team Website': text(payload.teamWebsite),
    'Trainer Name': text(payload.trainerName),
    'Trainer Email': text(payload.trainerEmail),
    'Trainer Phone': text(payload.trainerPhone),

    'Primary Highlight Video': text(payload.primaryHighlightVideo),
    'Full Game Film 1': text(payload.fullGameFilmOne),
    'Full Game Film 2': text(payload.fullGameFilmTwo),
    'Full Game Film 3': text(payload.fullGameFilmThree),
    'Hudl Profile': text(payload.hudlProfile),
    'YouTube Channel': text(payload.youtubeChannel),
    'Instagram': text(payload.instagram),
    'X / Twitter': text(payload.xTwitter),
    'TikTok': text(payload.tiktok),
    'Other Recruiting Link': text(payload.otherRecruitingLink),
    'Additional Video Notes': text(payload.additionalVideoNotes),

    'Transcript Upload': text(payload.transcriptUpload),
    'Report Card Upload': text(payload.reportCardUpload),
    'Awards Certificates': text(payload.awardsCertificates),
    'NCAA Eligibility Documents': text(payload.ncaaEligibilityDocuments),
    'Additional Documents': text(payload.additionalDocuments),

    'Player Bio': text(payload.playerBio),
    'Strength Tags': list(payload.strengthTags),

    'Recommendation Coach Name': text(payload.recommendationCoachName),
    'Recommendation Team': text(payload.recommendationTeam),
    'Recommendation Coach Email': text(payload.recommendationCoachEmail),
    'Recommendation Text': text(payload.recommendationText),

    'Athlete Signature': text(payload.athleteSignature),
    'Parent Signature': text(payload.parentSignature),
    'Signature Date': text(payload.signatureDate),

    'Image Placement JSON': JSON.stringify(payload.imagePlacement || {}),
    'Status': 'New Intake',
    'Submitted At': text(payload.submittedAt) || new Date().toISOString(),
  };
}

async function createAirtableRecord(payload: IntakePayload) {
  if (!AIRTABLE_BASE_ID || !AIRTABLE_API_KEY) {
    return { skipped: true, reason: 'Airtable environment variables are not configured.' };
  }

  const url = `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${encodeURIComponent(AIRTABLE_TABLE_NAME)}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${AIRTABLE_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ records: [{ fields: airtableFields(payload) }] }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(`Airtable error: ${data?.error?.message || response.statusText}`);
  }

  return data;
}

async function sendEmail(to: string, subject: string, html: string) {
  if (!RESEND_API_KEY) {
    return { skipped: true, reason: 'Resend environment variable is not configured.' };
  }

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: CPR_FROM_EMAIL,
      to,
      subject,
      html,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(`Email error: ${data?.message || response.statusText}`);
  }

  return data;
}

function athleteConfirmationEmail(payload: IntakePayload) {
  const firstName = text(payload.athleteFirstName) || 'Athlete';
  const profileId = text(payload.profileId);
  const completion = Number(payload.profileCompletion || 0);

  return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h1 style="color:#d71920">Welcome to Canadian Prospects Recruitment</h1>
      <p>Hi ${firstName},</p>
      <p>Your CPR athlete intake has been received. Our team will review your information, media links, documents, and image placement details.</p>
      <p><strong>Profile ID:</strong> ${profileId}</p>
      <p><strong>Current Profile Completion:</strong> ${completion}%</p>
      <h2>What happens next</h2>
      <ol>
        <li>CPR reviews your intake submission.</li>
        <li>Your athlete profile draft is created.</li>
        <li>Your videos, photos, academics, team info, and bio are organized for coach review.</li>
        <li>You will receive next-step instructions from your CPR advisor.</li>
      </ol>
      <p>Keep your profile updated. The more complete it is, the stronger your first impression becomes.</p>
      <p>Canadian Prospects Recruitment</p>
    </div>
  `;
}

function staffNotificationEmail(payload: IntakePayload) {
  return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#111">
      <h1 style="color:#d71920">New CPR Athlete Intake</h1>
      <p><strong>Name:</strong> ${text(payload.athleteFirstName)} ${text(payload.athleteLastName)}</p>
      <p><strong>Profile ID:</strong> ${text(payload.profileId)}</p>
      <p><strong>Graduation Year:</strong> ${text(payload.graduationYear)}</p>
      <p><strong>Position:</strong> ${text(payload.primaryPosition)}</p>
      <p><strong>School:</strong> ${text(payload.currentSchool)}</p>
      <p><strong>GPA:</strong> ${text(payload.gpaUnweighted)}</p>
      <p><strong>Email:</strong> ${text(payload.email)}</p>
      <p><strong>Parent:</strong> ${text(payload.parentOneName)} · ${text(payload.parentOneEmail)}</p>
      <p><strong>Highlight Video:</strong> ${text(payload.primaryHighlightVideo)}</p>
      <p><strong>Profile Completion:</strong> ${Number(payload.profileCompletion || 0)}%</p>
      <p><strong>Strength Tags:</strong> ${list(payload.strengthTags)}</p>
      <p>Review Airtable for the complete record and profile build details.</p>
    </div>
  `;
}

export async function POST(request: Request) {
  try {
    const payload = await request.json();

    const required = ['athleteFirstName', 'athleteLastName', 'dateOfBirth', 'graduationYear', 'email', 'parentOneName', 'currentSchool'];
    const missing = required.filter((key) => !text(payload[key]));

    if (missing.length) {
      return NextResponse.json({ error: `Missing required fields: ${missing.join(', ')}` }, { status: 400 });
    }

    const airtableResult = await createAirtableRecord(payload);

    await Promise.allSettled([
      sendEmail(text(payload.email), 'Welcome to Canadian Prospects Recruitment', athleteConfirmationEmail(payload)),
      sendEmail(CPR_STAFF_EMAIL, `New CPR Intake: ${text(payload.athleteFirstName)} ${text(payload.athleteLastName)}`, staffNotificationEmail(payload)),
    ]);

    return NextResponse.json({
      ok: true,
      message: 'Your CPR intake has been received. Confirmation details have been sent.',
      profileId: text(payload.profileId),
      airtable: airtableResult,
    });
  } catch (error) {
    console.error('CPR intake submission error:', error);
    const message = error instanceof Error ? error.message : 'Unknown submission error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
